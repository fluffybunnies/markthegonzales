<script type="text/javascript" src="includes/js/jquery.js"></script>
<script language="javascript" type="text/javascript" src="http://localhost/ThemeFive/wp-includes/js/tinymce/tiny_mce_popup.js"></script>
<style type="text/css" src="http://localhost/ThemeFive/wp-includes/js/tinymce/themes/advanced/skins/wp_theme/dialog.css"></style>
<link rel="stylesheet" href="includes/css/friendly_buttons_tinymce.css" />

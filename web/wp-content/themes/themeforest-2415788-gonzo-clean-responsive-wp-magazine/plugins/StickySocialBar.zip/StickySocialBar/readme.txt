=== Plugin Name ===
Plugin Name: Sticky Social Bar
Plugin URI: http://pixelgrade.com/sticky-social-bar
Description: Interactive WordPress plugin for adding cusomized social newtork buttons
Version: 1.0
Author: Pixel Grade 
Author URI: http://pixelgrade.com/

What does it do?
After activating it the Sticky Social Bar plugin is automatically adding a sliding bar with the default social buttons on your posts and pages.
Than you can costumize the plugin according to your wishes. You can arrange the position of the buttons with drag and drop from the Sticky Social Bar settings, enable/disable buttons, edit the current social button's API code and title, delete inactive buttons and of course you can also add new social buttons.
Positioning:
The plugin has 2 modes of positioning the widget.
By default the position is aligned to the left of the content and Sliding along with it when you scroll up and down.You can deactivate the option to align with the content.
You can set the top and left offset of the widget if you want to change it's position manually or you can set the position with drag and drop, than click Update and the position will automatically be saved for users view.
The second mode of positioning is "Stick to left" where the widget will stick to the left of the screen changing it's style a little bit.You can activate from the setting or if you are setting it's position with drag and drop right on the left of your screen it will automatically change to "Stick to left".You can notice after you click update that "Stick to left option" is automatically checked. 
You can also change the theme of the widget and according to the "Stick to left" or "Default option" the theme will automatically change.You can make your own theme and add them to the css folder and the list of the themes will automatically update.


How to use?
Basically the plugin is pretty suggestive to use but

